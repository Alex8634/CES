public class CarException extends RuntimeException {

}